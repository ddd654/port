3D Curtain Template
=========

A list of split blocks that reunite on scrolling, simulating a movement along the z-axis with the help of CSS transformations and jQuery.

[Article on CodyHouse](http://codyhouse.co/gem/3d-curtain-template/)

[Demo](http://codyhouse.co/demo/3d-curtain-template/index.html)
 
[Terms](http://codyhouse.co/terms/)
